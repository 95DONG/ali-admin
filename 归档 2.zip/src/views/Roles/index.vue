<template>
  <div>
    <!-- 面包屑 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>活动管理</el-breadcrumb-item>
      <el-breadcrumb-item>活动列表</el-breadcrumb-item>
      <el-breadcrumb-item>活动详情</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片 -->
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <div>
          <el-button type="primary" @click="setUserForm = true"
            >添加用户</el-button
          >
        </div>
      </div>
      <!-- 表单 -->
      <el-table stripe :data="userList" border style="width: 100%">
        <el-table-column prop="id" label="#" width="50" type="expand">
          <template slot-scope="{ row }">
            <!-- <div v-for="(item, index) in row.children" :key="index">
              <div class="outside" @click="onBtn(row)">
                <div class="oneInside">
                  <el-tag>{{ item.authName }}</el-tag>
                </div>
                <div class="box">
                  <div
                    v-for="(item1, index1) in item.children"
                    :key="index1"
                    class="twoInside"
                  >
                    <div class="left">
                      <el-tag>{{ item1.authName }}</el-tag>
                    </div>
                    <div class="right">
                      <el-tag
                        v-for="(item2, index2) in item1.children"
                        :key="index2"
                        >{{ item2.authName }}</el-tag
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div> -->
            <el-row
              v-for="(item, index) in row.children"
              :key="index"
              type="flex"
              align="middle"
              class="border-top"
            >
              <el-col :span="3">
                <el-tag>{{ item.authName }}</el-tag>
                <i class="el-icon-caret-right"></i>
              </el-col>
              <el-col :span="21">
                <el-row
                  v-for="(item1, index1) in item.children"
                  :key="index1"
                  type="flex"
                >
                  <el-col :span="6">
                    <el-tag type="success">{{ item1.authName }}</el-tag>
                    <i class="el-icon-caret-right"></i>
                  </el-col>
                  <el-col>
                    <el-tag
                      closable
                      :disable-transitions="false"
                      type="info"
                      :span="18"
                      v-for="(item2, index2) in item1.children"
                      :key="index2"
                      @close="handleClose(row.id, item2.id, index2, row)"
                      >{{ item2.authName }}</el-tag
                    >
                  </el-col>
                </el-row>
              </el-col>
            </el-row>
          </template>
        </el-table-column>
        <el-table-column type="index" label="#"> </el-table-column>
        <el-table-column prop="roleName" label="角色名称"> </el-table-column>
        <el-table-column prop="roleDesc" label="角色描述"> </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              @click="onPutClick(scope.row)"
              type="primary"
              size="mini"
              icon="el-icon-edit"
              >编辑</el-button
            >
            <el-button
              type="primary"
              icon="el-icon-delete"
              size="mini"
              class="del"
              @click="delUserClick(scope.row.id)"
              >删除</el-button
            >
            <el-button
              type="primary"
              icon="el-icon-setting"
              size="mini"
              class="set"
              @click="settingNoun = !settingNoun"
              >分配角色</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { getRolesList, delRolesControl } from '@/api/roles'
export default {
  created () {
    this.getRolesInfo()
  },
  data () {
    return {
      userList: [],
      activeName: 0
    }
  },
  methods: {
    async getRolesInfo () {
      const res = await getRolesList()
      this.userList = res.data.data
      console.log('roles', res)
    },
    handleChange (val) {
      console.log(val)
    },
    onBtn (row) {
      console.log(row)
    },
    // 删除标签
    async handleClose (id1, id2, index2, row) {
      console.log(id1, id2)
      const obj = {
        roleId: id1, rightId: id2
      }
      try {
        const res = await delRolesControl(obj)
        row.children = res.data.data
        console.log(res)
      } catch (error) {
        console.log(error)
      }
      // this.dynamicTags.splice(this.dynamicTags.indexOf(index2), 1)
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
// 卡片样式
.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}

.box-card {
  width: 100%;
  margin-top: 20px;
}
// 角色列表下拉布局
.outside {
  display: flex;
  // justify-content: center;
  align-items: center;
  .oneInside {
    // background-color: pink;
    flex: 1;
  }
  .box {
    flex: 9;
  }
  .twoInside {
    // align-items: center;
    display: flex;

    // flex-direction: column;
    flex: 9;
    .left {
      flex: 3;
      // background-color: skyblue;
      // border-bottom: 2px solid #333;
    }
    .right {
      flex: 9;
    }
  }
}
.border-top {
  border-bottom: 1px solid #333;
}
</style>
