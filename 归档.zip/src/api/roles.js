import request from '@/utils/index'

/**
 *获取角色列表
 * @returns
 */
export const getRolesList = () => {
  return request({
    url: 'roles'
  })
}
/**
 *删除角色指定权限
 * @param {*} param0
 * @returns
 */
export const delRolesControl = (data) => {
  return request({
    url: `roles/${data.roleId}/rights/${data.rightId}`,
    method: 'DELETE'

  })
}
